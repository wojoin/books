package com.springinaction.training.model;

import java.beans.PropertyEditorSupport;


public class EmailPropertyEditor extends PropertyEditorSupport {
  
}
