package com.springinaction.training;

public class CourseException extends Exception {
  public CourseException() {}
  
  public CourseException(String message) {
    	super(message);
  }
}
