package com.springinaction.payment;


public class SettlementException extends Exception {

}
