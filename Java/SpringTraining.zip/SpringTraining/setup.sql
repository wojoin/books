INSERT INTO user VALUES ('admin', 'admin');
INSERT INTO authorities VALUES ('admin', 'ROLE_INSTRUCTOR');
INSERT INTO authorities VALUES ('admin', 'ROLE_STUDENT');
