package com.springinaction.training.model;


public class Email {
  private String email="";
  
  public Email() {}
  
  public Email(String email) {
    this.email = email;
  }
  
  public String getEmail() {
    return email;
  }
  
  public void setEmail(String email) {
    this.email = email;
  }
}
