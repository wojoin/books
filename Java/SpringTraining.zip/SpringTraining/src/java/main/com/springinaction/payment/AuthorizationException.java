package com.springinaction.payment;


public class AuthorizationException extends Exception {

}
