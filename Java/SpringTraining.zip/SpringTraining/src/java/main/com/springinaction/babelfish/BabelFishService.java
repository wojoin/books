package com.springinaction.babelfish;


public interface BabelFishService {
  public String BabelFish(String translationMode, String sourceData);
}
